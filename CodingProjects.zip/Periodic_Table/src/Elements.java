
public class Elements {
	//Element name, abb, atomic # and atomic weight, fun fact - all private to this class
	private String name; 
	private String abv; 
	private int numAtomic; 
	private double numWeight; 
	private String funfact; 
	
	//Constructor 
	public Elements(){
		
	}
	public Elements(String name, String abv, int numAtomic, double numWeight, String funfact){
		this.name = name; 
		this.abv = abv; 
		this.numAtomic = numAtomic; 
		this.numWeight = numWeight; 
		this.funfact = funfact; 
	}
	
	//Getters
	public String getName(){return this.name;}
	public String getAbv(){ return this.abv; }
	public int getNumAtomic() {return this.numAtomic; }
	public double getNumWeight() { return this.numWeight; }
	public String getFunFact() { return this.funfact; }
	
	public void setName(String name) { this.name = name; }
	public void setAbv(String abv){ this.abv = abv; }
	public void setNumAtomic(int numAtomic) { this.numAtomic= numAtomic; }
	public void setNumWeight(double numWeight) { this.numWeight= numWeight; }
	public void setFunFact(String funfact) { this.funfact = funfact; }
	
	
	
	
	
	
}
