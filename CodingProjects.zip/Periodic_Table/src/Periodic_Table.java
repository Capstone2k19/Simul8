import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList; 

public class Periodic_Table {

	//global variable bufferedreader
	public static BufferedReader cin = new BufferedReader (new InputStreamReader (System.in));
	
	public static void main(String[] args) throws IOException {
		//We will be using arraylists
		
		ArrayList < Elements> PeriodicTable  = new ArrayList <Elements> (); 
		while(true){
			String MenuOption = MenuInput(); 
			
			if(MenuOption.equals("A") || MenuOption.equals("a")){
				boolean elementsadded = AddElement(PeriodicTable); 
			}
			
			if(MenuOption.equals("D")||MenuOption.equals("d")){
				DisplayElements(PeriodicTable); 
			}
			if(MenuOption.equals("Q")|| MenuOption.equals("q")){
				System.out.println("See ya later!");
				System.exit(0); 
			}
		
		}
	}

	private static void DisplayElements(ArrayList<Elements> E) {
		
		int atomicnum = getInteger("Enter the atomic number", 0, E.size());
		//to get this element out, we create another element, call it xout
		Elements xout = new Elements(); 
		//Fetch the info of the element at the given atomicnumber, you get it from your arraylist
		xout = E.get(atomicnum-1); 
		System.out.format(" Atomic Number: %d \n Element: %s \n Abbreviation: %3s \n Atomic Weight: %f \n Fun Fact: %s\n\n",
				xout.getNumAtomic(), xout.getName(), xout.getAbv(), xout.getNumWeight(), xout.getFunFact()); 
		
		
	}

	private static boolean AddElement(ArrayList <Elements> E) {
	
		int numElements = 0; 
		numElements = getInteger("# of Elements to Add: ", 0, 118); 
		
		if(numElements==0){
			return false;
		}
		else{
			for(int i= 0; i < numElements; i++){
				
				//Get all of your info
				System.out.format("Element %d\n", E.size()+1); 
				String name= getString("Element name: "); 
				String abv = getString("Element abbreviation: "); 
				int numAtomic= getInteger("Atomic #: ", 1, 118 ); 
				double numWeight = getDouble("Atomic Weight: ", 0, 294);
				String funfact = getString("Fun fact about this element: ");
	
				//when you call this constructor, everything is set! 
				Elements x = new Elements(name, abv, numAtomic, numWeight, funfact); 
				
				//E is your huge arraylist, you append x (this new element you've got from user) to the end of E
				E.add(x);
			}
		return true; 
		}
	}

	private static void displayMenu() {
		System.out.print("PERIODIC TABLE OF ELEMENTS\n"+ "A - Add Elements\n" + "E - Edit Elements \n" + "D - Display Elements \n" + "Q - Quit\n"); 
	}

	public static String MenuInput() throws IOException{
		String MenuIn="i";
		boolean valid=false;
		do{
			valid=false;
			displayMenu();
			System.out.print("\nEnter Option: "); 
			MenuIn = cin.readLine();
			if(MenuIn.equals("A") || MenuIn.equals("a") ||MenuIn.equals("E")|| MenuIn.equals("e")|| MenuIn.equals("D")||MenuIn.equals("d")||MenuIn.equals("Q")|| MenuIn.equals("q")){ 
				//Do nothing, input is valid
				}
			else{
				System.out.println("ERROR: Invalid menu choice!\n");
				valid=true;
			}
		}while(valid); 
		
		return MenuIn; 
		
	}
	
	public static int getInteger(String prompt, int LB, int UB){
		boolean valid=false; 
		int num=0;
		do{
			valid=false; 
			try{
				System.out.print(prompt); 
				num=Integer.parseInt(cin.readLine());
			} 
			catch (NumberFormatException | IOException e) {
				System.out.format("ERROR: Input must be an integer in [%d, %d]!\n", LB, UB);  
				valid=true;
			} 
			if(valid ==false && ((num <LB)|| num>UB)){
				System.out.format("ERROR: Input must be an integer in [%d, %d]!\n", LB, UB);  
				valid=true;
			}
		}while(valid); 
		
		return num; 
	}
	
	public static double getDouble(String prompt, double LB, double UB){
		boolean valid=false; 
		double val=0.00;
		do{
			valid=false; 
			try{
				System.out.print(prompt); 
				val=Double.parseDouble((cin.readLine()));
			} 
			catch (NumberFormatException | IOException e ) {
				System.out.format("\nERROR: Input must be a real number in [%.2f, %.2f]!\n\n", LB, UB);  
				valid=true;
			} 
			if(valid==false && (val < LB || val > UB )){
				System.out.format("\nERROR: Input must be a real number in [%.2f, %.2f]!\n\n", LB, UB);  
				valid=true;
			}
		}while(valid); 
		
		return val; 
	}
	
	public static String getString(String prompt){
		String thisstring = "nada"; 
		boolean valid = false; 
		
		do{
			try {
				System.out.print(prompt);
				thisstring = cin.readLine();
			} catch (IOException e) {
				System.out.println("This isn't a string!"); 
				valid=true; 
			}
		}while (valid); 
		 
		return thisstring; 
	}
}
